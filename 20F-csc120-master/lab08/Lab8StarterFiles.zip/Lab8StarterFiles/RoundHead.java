// RoundHead.java

import java.awt.*;

public class RoundHead {

    private final int VIEWER_WIDTH  = 600;
    private final int VIEWER_HEIGHT = 500;
    
    private boolean isHappy;
    private Color hatColor;
    private int over, down;             // corner of the face.
    private int size;                   // size of face
    private int verticalStepSize;       // how far to move
    private int horizontalStepSize;     // how far to move
    private String nickName;
    
    public RoundHead(boolean startHappiness, Color hc,
                       int o, int d,
                       int hStepSize,
                       int vStepSize,
                       int s,
                       String n) {
					   
        isHappy = startHappiness;
        hatColor = hc;
        over = o;
        down = d;
        horizontalStepSize = hStepSize;
        verticalStepSize = vStepSize;
        size = s;
        nickName = n;
    } // end of constructor

    public void draw(Graphics g) {
        // Draw the RoundHead's face.
        if (isHappy) {
            g.setColor(Color.YELLOW);
        }
        else {
            g.setColor(Color.PINK);
        }
        g.fillOval(over, down, size, size);

        // Put a black outline around face.
        g.setColor(Color.BLACK);
        g.drawOval(over, down, size, size);

        // Draw the RoundHead's hat.
        g.setColor(hatColor);
        g.fillRect(over, down, size, size/10);
        g.fillRect(over+size/4, down-size/3, size/2, size/3);

        // Draw the RoundHead's facial features in black, based on mood.
        g.setColor(Color.BLACK);

        if (isHappy) {
            g.fillOval(over+size/5, down+3*size/10, size/5, size/5);
            g.fillOval(over+3*size/5, down+3*size/10, size/5, size/5);
            g.drawArc(over+3*size/10, down+size/2, 2*size/5, 3*size/10, 190, 160);
        } 
        else {
            g.fillRect(over+size/5, down+3*size/10, size/5, size/10);
            g.fillRect(over+3*size/5, down+3*size/10, size/5, size/10);
            g.drawArc(over+3*size/10, down+7*size/10, 2*size/5, 3*size/10, 10, 160);
        } 
        
        g.setColor(Color.BLUE);        
        g.drawString(nickName, over, down + size + 10);
    } // end of draw()

    public void moveVertically() {
        // Change direction if the move would make the RoundHead
        // go past either the top or bottom edge of the viewer window.
        
        if (   (down + verticalStepSize <= 0)
            || (down + size + verticalStepSize >= VIEWER_HEIGHT) ) {
            
            verticalStepSize = -1 * verticalStepSize;
        }

        // Now make a vertical move.
        down += verticalStepSize;
    } // end of moveVertically()

    public void moveHorizontally() {
        // Change direction if the move would make the RoundHead
        // go past either the top or bottom edge of the viewer window.

        if (   (over + horizontalStepSize <= 0)
            || (over + size + horizontalStepSize >= VIEWER_WIDTH) ) {
            
            horizontalStepSize = -1 * horizontalStepSize;
        } 

        // Now make a horizontal move.
        over += horizontalStepSize;
    } // end of moveHorizontally()

    public void changeMood() {
        if (isHappy) {
            isHappy = false;
        }
        else {
            isHappy = true;
        }
    } // end of changeMood()

} // end of class RoundHead
