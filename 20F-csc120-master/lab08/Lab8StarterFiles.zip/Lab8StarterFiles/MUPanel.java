/* 
    CSC 120 Lab 8
    Sammy Student
    Today's Date

    Practice with an Array of RoundHead objects.

    Originally authored by various UMU CSIS Dept. faculty
    Most recently modified: Oct. 2, 2014
 */

import java.awt.*;
import javax.swing.*;

public class MUPanel extends JPanel {

    private RoundHead firstOne, secondOne, thirdOne, fourthOne, fifthOne, sixthOne;
    

    // constructor method
    public MUPanel() {
        setLayout(null);
        setPreferredSize(new Dimension(600, 500));
        setName("Mount Union Java Program");
        setUp();
        setBackground(Color.WHITE);

        firstOne  = new RoundHead(false, Color.GREEN, 480, 250, -5, 30, 40, "Sally");
        secondOne = new RoundHead(true, Color.BLUE, 300, 150, 25, -60, 30, "Joe");
        thirdOne  = new RoundHead(true, Color.ORANGE, 540, 150, 0, -6, 20, "Chuck");
        fourthOne = new RoundHead(false, Color.LIGHT_GRAY, 400, 100, 15, 10, 25, "Zelda");
        fifthOne  = new RoundHead(true, Color.RED, 15, 200, -15, -15, 45, "Me");
        sixthOne  = new RoundHead(false, Color.MAGENTA, 50, 300, -10, 0, 35, "Jorge");
        
    } // end of constructor

    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g); // This line must be first in this method!

        firstOne.draw(g);
        secondOne.draw(g);
        thirdOne.draw(g);
        fourthOne.draw(g);
        fifthOne.draw(g);
        sixthOne.draw(g);
		
    } // end of paintComponent()
    
    
    public void moveObjects() {
        
        firstOne.moveVertically();
        secondOne.moveVertically();
        thirdOne.moveVertically();
        fourthOne.moveVertically();
        fifthOne.moveVertically();
        sixthOne.moveVertically();
        
        firstOne.moveHorizontally();
        secondOne.moveHorizontally();
        thirdOne.moveHorizontally();
        fourthOne.moveHorizontally();
        fifthOne.moveHorizontally();
        sixthOne.moveHorizontally();
        
    } // end of moveObjects()

    
    public void changeObjectMoods() {
        
        firstOne.changeMood();
        secondOne.changeMood();
        thirdOne.changeMood();
        fourthOne.changeMood();
        fifthOne.changeMood();
        sixthOne.changeMood();
        
    } // end of changeObjectsMood()
    
    
    
    
    /***********************************************
     * Do NOT change or delete anything below here!
     ***********************************************/
    public void setUp() {
        for (Component c: getComponents())
            c.setSize(c.getPreferredSize());
        JFrame f = new JFrame(getName());
        f.setContentPane(this);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.pack();
        f.setVisible(false);    
    }

    public static void main(String args[]){new MUPanel();}

} // end of class MUPanel
