<?php // $Id: version.php,v 1.29.2.2 2008/09/27 00:40:00 ethem Exp $

$plugin->version  = 2006112903;
$plugin->requires = 2007101000;

?>
