<?php // $Id: version.php,v 1.36.2.1 2008/03/03 11:48:41 moodler Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2007101509;
$module->requires = 2007101509;  // Requires this Moodle version
$module->cron     = 60;

?>
