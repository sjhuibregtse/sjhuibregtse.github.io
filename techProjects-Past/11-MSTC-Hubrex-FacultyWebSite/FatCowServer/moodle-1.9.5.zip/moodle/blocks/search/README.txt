This block is a revamping of the Google Summer Of Code Project (2006) on Global Search engine
for Moodle. New block version is completed and internationalized according to Moodle multilengual support.

This block instanciates a startup database model for the search engine.

## Installing

You need installing the following elements in order the global search to be available :

1. The global search bloc (this block)
2. update the /search root package from CVS
3. The antiword libraries
4. The xpdf libraries

Both last libraries are provided as a patch called "global_search_libraries" in the contrib section.