<?php //$Id: config.php,v 1.2 2005/04/21 13:25:43 defacer Exp $
//
// Optional course format configuration file
//
// This file contains any specific configuration settings for the
// social format.
//
// The default blocks layout for this course format:
    $format['defaultblocks'] = 'participants,search_forums,calendar_upcoming,'.
                               'social_activities,recent_activity,admin,course_list';

?>
